﻿This project does not contain any code, all projects here have their sources in an external open source repository.  This project is here to extract the required bits from the module zips and copy the zips to the correct locaktions during a release biuld.

RadEditor Provider source can be found at http://radeditor.codeplex.com
DDRMenu source can be found at http://dnnddrmenu.codeplex.com/