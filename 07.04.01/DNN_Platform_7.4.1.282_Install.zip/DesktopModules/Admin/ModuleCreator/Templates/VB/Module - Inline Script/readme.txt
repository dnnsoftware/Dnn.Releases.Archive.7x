Template Name  : Module - Inline Script
Compatible With: DNN 6.x, 7.x

An Inline Script module has both the user interface and code as part of the same file

template.ascx

(Include any special instructions for this Module Template in this area)
