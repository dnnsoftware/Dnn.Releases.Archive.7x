#Region "Copyright"

' 
' Copyright (c) _YEAR_
' by _OWNER_
' 

#End Region

#Region "Using Statements"

#End Region

Namespace _OWNER_._MODULE_

    Public Class _MODULE_Controller

    End Class

End Namespace
