using System.Reflection;
using System.Runtime.InteropServices;

// General Information about an assembly is controlled through the following 
// set of attributes. Change these attribute values to modify the information
// associated with an assembly.
[assembly: AssemblyTitle("DotNetNuke.Instrumentation")]
[assembly: AssemblyDescription("DotNetNuke's Instrumentation Framework")]

// Setting ComVisible to false makes the types in this assembly not visible 
// to COM components.  If you need to access a type in this assembly from 
// COM, set the ComVisible attribute to true on that type.

[assembly: ComVisible(false)]     

// The following GUID is for the ID of the typelib if this project is exposed to COM

[assembly: Guid("cb8f5692-4ea1-4397-85ec-094334605289")]

