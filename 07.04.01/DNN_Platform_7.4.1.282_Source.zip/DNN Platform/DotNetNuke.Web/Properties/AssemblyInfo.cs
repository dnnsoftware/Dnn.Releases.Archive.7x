#region Usings

using System;
using System.Reflection;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;
using System.Web.UI;

#endregion

// General Information about an assembly is controlled through the following 
// set of attributes. Change these attribute values to modify the information
// associated with an assembly.

// Review the values of the assembly attributes

[assembly: AssemblyTitle("DotNetNuke.Web")]
[assembly: AssemblyDescription("Open Source Web Application Framework")]
[assembly: CLSCompliant(true)]
[assembly: ComVisible(false)]
//The following GUID is for the ID of the typelib if this project is exposed to COM

[assembly: Guid("99d0e26d-a924-41d2-a195-33496a3f48ad")]

[assembly: InternalsVisibleTo("DotNetNuke.Tests.Content")]
[assembly: InternalsVisibleTo("DotNetNuke.Tests.Messaging")]
[assembly: InternalsVisibleTo("DotNetNuke.Tests.Web")]
[assembly: WebResource("DotNetNuke.Web.UI.WebControls.Resources.TermsSelector.js", "application/x-javascript")]
