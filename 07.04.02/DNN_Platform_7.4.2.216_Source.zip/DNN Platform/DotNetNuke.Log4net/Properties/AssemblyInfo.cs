﻿using System;
using System.Diagnostics;
using System.Reflection;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;
using System.Security;

[assembly: AllowPartiallyTrustedCallers]
[assembly: AssemblyCompany("Apache Software Foundation")]
[assembly: AssemblyConfiguration("")]
[assembly: AssemblyCopyright("Copyright © Apache Software Foundation 2007")]
[assembly: AssemblyDescription("DotNetNuke branded version of log4net")]
[assembly: AssemblyFileVersion("3.0.1.0")]
[assembly: AssemblyProduct("log4net")]
[assembly: AssemblyTitle("dotnetnuke.log4net")]
[assembly: AssemblyTrademark("")]
[assembly: AssemblyVersion("3.0.1.0")]
[assembly: CLSCompliant(true)]
[assembly: CompilationRelaxations(8)]
[assembly: ComVisible(false)]
[assembly: Debuggable(DebuggableAttribute.DebuggingModes.IgnoreSymbolStoreSequencePoints)]
[assembly: Guid("d443a5b8-29a8-43b6-bcb7-0428190e710a")]
[assembly: RuntimeCompatibility(WrapNonExceptionThrows=true)]
