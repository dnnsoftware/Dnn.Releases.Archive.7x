﻿namespace ClientDependency.Core
{
    public enum CssMediaType
    {
        All, Screen, Print
    }
}