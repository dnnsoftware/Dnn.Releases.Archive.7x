Template Name  : Module - HTML
Compatible With: DNN 6.x, 7.x

An HTML Module

template.html - user interface
template.ascx - user control wrapper

(Include any special instructions for this Module Template in this area)