#Region "Copyright"

' 
' Copyright (c) [YEAR]
' by [OWNER]
' 

#End Region

#Region "Using Statements"

#End Region

Namespace [OWNER].[MODULE]

    Public Class [MODULE]Controller

    End Class

End Namespace
