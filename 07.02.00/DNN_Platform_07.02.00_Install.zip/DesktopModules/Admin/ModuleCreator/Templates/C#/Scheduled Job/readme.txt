Template Name  : Scheduled Job
Compatible With: DNN 6.x, 7.x

A Scheduled Job class file that will be created in App_Code

templateJob.cs

*NOTE: When you create a Class File there will be a momentary delay while the DNN application restarts

(Include any special instructions for this Module Template in this area)