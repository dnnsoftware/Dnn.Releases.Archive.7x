Template Name  : Class File
Compatible With: DNN 6.x, 7.x

A Class File that will be created in App_Code

template.vb

*NOTE: When you create a Class File there will be a momentary delay while the DNN application restarts

(Include any special instructions for this Module Template in this area)