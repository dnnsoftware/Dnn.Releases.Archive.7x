Template Name  : Web Service API
Compatible With: DotNetNuke 7.x

A Web Service Controller utilizing Web API that will be created in App_Code

templateAPIController.cs
templateRouteMapper.cs

*NOTE: When you create a Class File there will be a momentary delay while the DotNetNuke application restarts

(Include any special instructions for this Module Template in this area)
